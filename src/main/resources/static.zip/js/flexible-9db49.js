!function(e, t) {
    function i() {
        var t = n.getBoundingClientRect().width;
        t / m > 750 && (t = 750 * m);
        var i = t / 10;
        n.style.fontSize = i + "px",
            s.rem = e.rem = i
    }
    var a, r = e.document, n = r.documentElement, o = r.querySelector('meta[name="viewport"]'), l = r.querySelector('meta[name="flexible"]'), m = 0, d = 0, s = t.flexible || (t.flexible = {});
    if (o) {
        var c = o.getAttribute("content").match(/initial\-scale=([\d\.]+)/);
        c && (d = parseFloat(c[1]),
            m = parseInt(1 / d))
    } else if (l) {
        var p = l.getAttribute("content");
        if (p) {
            var u = p.match(/initial\-dpr=([\d\.]+)/)
                , f = p.match(/maximum\-dpr=([\d\.]+)/);
            u && (m = parseFloat(u[1]),
                d = parseFloat((1 / m).toFixed(2))),
            f && (m = parseFloat(f[1]),
                d = parseFloat((1 / m).toFixed(2)))
        }
    }
    if (!m && !d) {
        var h = e.navigator.userAgent
            , v = (!!h.match(/android/gi),
            !!h.match(/iphone/gi))
            , x = v && !!h.match(/OS 9_3/)
            , b = e.devicePixelRatio;
        m = v && !x ? b >= 3 && (!m || m >= 3) ? 3 : b >= 2 && (!m || m >= 2) ? 2 : 1 : 1,
            d = 1 / m
    }
    if (n.setAttribute("data-dpr", m),
        !o)
        if (o = r.createElement("meta"),
            o.setAttribute("name", "viewport"),
            o.setAttribute("content", "initial-scale=" + d + ", maximum-scale=" + d + ", minimum-scale=" + d + ", user-scalable=no"),
            n.firstElementChild)
            n.firstElementChild.appendChild(o);
        else {
            var w = r.createElement("div");
            w.appendChild(o),
                r.write(w.innerHTML)
        }
    e.addEventListener("resize", function() {
        clearTimeout(a),
            a = setTimeout(i, 300)
    }, !1),
        e.addEventListener("pageshow", function(e) {
            e.persisted && (clearTimeout(a),
                a = setTimeout(i, 300))
        }, !1),
        "complete" === r.readyState ? r.body.style.fontSize = 12 * m + "px" : r.addEventListener("DOMContentLoaded", function() {
            r.body.style.fontSize = 12 * m + "px"
        }, !1),
        i(),
        s.dpr = e.dpr = m,
        s.refreshRem = i,
        s.rem2px = function(e) {
            var t = parseFloat(e) * this.rem;
            return "string" == typeof e && e.match(/rem$/) && (t += "px"),
                t
        }
        ,
        s.px2rem = function(e) {
            var t = parseFloat(e) / this.rem;
            return "string" == typeof e && e.match(/px$/) && (t += "rem"),
                t
        }
}(window, window.lib || (window.lib = {}));
